console.log('1')
setTimeout(function afterTwoSeconds() {
  console.log('2')}, 2000)
console.log('3')