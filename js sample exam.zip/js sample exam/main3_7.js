var myarr=[8,5,2,6,4,7]
var reverce=[]
var n=myarr.length-1
for(let i=0;i<=n;i++){
    reverce[i]=myarr[n-i]
}
console.log(reverce)