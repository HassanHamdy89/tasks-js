function Names(){
    let fname='ahmed',
     lname='ali';
return [fname,lname]
}
console.log(Names())