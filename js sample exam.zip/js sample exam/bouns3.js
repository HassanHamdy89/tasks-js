var arr = [{ name: 'JOHN' }, 
  {  name: 'JENNIE'}, 
  {  name: 'JENNAH' }];

function userExists(name) {
  return arr.some(function(x) {
    return x.name === name;
  }); 
}

console.log(userExists('JOHN')); 
console.log(userExists('JUMBO'));