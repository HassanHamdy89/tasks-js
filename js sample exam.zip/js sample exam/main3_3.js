var myarr=[5,4,8,9,15,2,4,7,1,6,8,]
var biggest=myarr[0]

for(let i =0;i<myarr.length;i++){
    if(myarr[i]>biggest){
        var index=i
        biggest=myarr[i]
    }
}
console.log('the biggest element is '+biggest+' his index is '+index)