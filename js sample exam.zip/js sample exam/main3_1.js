const obj = {
    one: 5,
    two: 15,
    three: 45,
  };
  
  
  const values = Object.values(obj);
  
  const sum = values.reduce((accumulator, value) => {
    return accumulator + value;
  }, 0);
  
  console.log(sum); 
  