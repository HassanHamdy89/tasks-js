let arra=['c++','java','python']
let text=prompt('Enter the text in first of array')
arra.unshift(text)
console.log(arra)

let arra=['c++','java','python']
let text=prompt('Enter the text in last of array')
arra.push(text)
console.log(arra)

