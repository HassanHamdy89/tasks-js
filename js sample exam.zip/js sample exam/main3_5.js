let n1=Number(prompt('Enter the first number'))
let n2=Number(prompt('Enter the second number '))
let op=prompt('enter the opretor + or ! or - or /')
function fac(n,j){
    let fa=1
    for(let i=j;i<=n;i++){
        fa=fa*i
    }
    return fa
}
switch(op){
    case'+':
    console.log('sum = '+(n1+n2))
    break;
    case'!':
    console.log('product = '+fac(n1,n2))
    break;
    case'-':
    console.log('difference = '+(n1-n2))
    break;
    case'/':
    console.log('dividend = '+(n1/n2))


    }

