let s =prompt('The word is = ')
let str=' '
for(let i=s.length;i>=0;i--){

    str=str+s.charAt(i)

}
console.log(str)