let num=Number(prompt('enter the number = '))
/*var i=1
var fac=1
while(i<=num){
     fac=fac*i
     i++
}
console.log('the factorial = '+fac)*/
let num=Number(prompt('Enter the number = '))
function fac(n){
    if(n>1)
    return n*fac(n-1)
    else
    return 1
}
console.log('the factorial of '+num+' is = '+fac(num))
