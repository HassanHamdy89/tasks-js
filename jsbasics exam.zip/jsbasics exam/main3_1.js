let arr=[1,2,3,4]
arr.push(5,6)
arr.unshift(0)
console.log(arr)