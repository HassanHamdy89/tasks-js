let text=prompt('enter the text')
for(let i=0;i<text.length;i++){
    document.write(text.charAt(i)+" ")
}