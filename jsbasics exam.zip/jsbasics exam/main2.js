let num1 = Number(prompt('enter the first number = '))
let num2 = Number(prompt('enter the second number = '))
num1=num1+num2
num2=num1-num2
num1=num1-num2

console.log('the first number = '+num1)
console.log('the second number = '+num2)