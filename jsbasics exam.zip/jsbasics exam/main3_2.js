let obj={
    a:1,
    b:2
}

let arr=Object.entries(obj)
document.write(arr)
